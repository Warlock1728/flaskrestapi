import unittest
from myapp import app, db
import json


class TestTAApp(unittest.TestCase):
    def setUp(self):
        app.config['TESTING'] = True
        app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
        db.create_all()
        self.client = app.test_client()

        # create a test user for authentication
        self.username = 'test_user'
        self.password = 'test_password'
        response = self.client.post('/login', json={'username': self.username, 'password': self.password})
        self.access_token = json.loads(response.data)['access_token']

    def tearDown(self):
        db.session.remove()
        db.drop_all()

    def test_login(self):
        response = self.client.post('/login', json={'username': 'invalid_user', 'password': 'invalid_password'})
        self.assertEqual(response.status_code, 401)
        self.assertIn(b'Invalid username or password', response.data)

        response = self.client.post('/login', json={'username': self.username, 'password': self.password})
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'access_token', response.data)

    def test_protected_route(self):
        response = self.client.get('/protected')
        self.assertEqual(response.status_code, 401)
        self.assertIn(b'Missing Authorization Header', response.data)

        headers = {'Authorization': f'Bearer {self.access_token}'}
        response = self.client.get('/protected', headers=headers)
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'You are authorized to access this route', response.data)

    def test_tas_routes(self):
        # create a new TA
        headers = {'Authorization': f'Bearer {self.access_token}', 'Content-Type': 'application/json'}
        data = {'native_english_speaker': True, 'course_instructor': 'John Doe', 'course': 'Intro to CS', 
                'semester': 1, 'class_size': 30, 'class_attribute': 1}
        response = self.client.post('/tas', headers=headers, json=data)
        self.assertEqual(response.status_code, 201)
        self.assertIn(b'New TA has been added successfully.', response.data)

        # get all TAs
        response = self.client.get('/tas')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'John Doe', response.data)

        # get a specific TA
        ta_id = json.loads(response.data)['TAs'][0]['id']
        response = self.client.get(f'/tas/{ta_id}')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'John Doe', response.data)

        # update a TA
        data = {'native_english_speaker': False, 'course_instructor': 'Jane Smith', 'course': 'Advanced CS', 
                'semester': 2, 'class_size': 20, 'class_attribute': 2}
        response = self.client.put(f'/tas/{ta_id}', headers=headers, json=data)
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'TA has been updated successfully.', response.data)

        # delete a TA
        response = self.client.delete(f'/tas/{ta_id}', headers=headers)
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'TA has been deleted successfully.', response.data)
