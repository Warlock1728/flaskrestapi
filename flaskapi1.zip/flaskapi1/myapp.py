from flask import Flask,jsonify, request
from flask_restful import Resource, Api, reqparse
from flask_jwt_extended import JWTManager, jwt_required, create_access_token, get_jwt_identity
from flask_sqlalchemy import SQLAlchemy
import secrets
from sqlalchemy import create_engine, Column, Integer, String, Boolean
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base
from flask.json import JSONEncoder
from marshmallow import Schema, fields



class CustomJSONEncoder(JSONEncoder):
    def default(self, obj):
        if callable(obj):
            return obj.__name__
        elif isinstance(obj, TA):
            return {
                'id': obj.id,
                'native_english_speaker': obj.native_english_speaker,
                'course_instructor': obj.course_instructor,
                'course': obj.course,
                'semester': obj.semester,
                'class_size': obj.class_size,
                'class_attribute': obj.class_attribute
            }
        return super().default(obj)

class TASchema(Schema):
    id = fields.Integer()
    native_english_speaker = fields.Boolean()
    course_instructor = fields.String()
    course = fields.String()
    semester = fields.Boolean()
    class_size = fields.Integer()
    class_attribute = fields.Integer()



app = Flask(__name__)
app.json_encoder = CustomJSONEncoder
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///ta.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['JWT_SECRET_KEY'] = secrets.token_hex(16)


api = Api(app)
jwt = JWTManager(app)
db = SQLAlchemy(app)

class TA(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    native_english_speaker = db.Column(db.Boolean, nullable=False)
    course_instructor = db.Column(db.String(64), nullable=False)
    course = db.Column(db.String(64), nullable=False)
    semester = db.Column(db.Integer, nullable=False)
    class_size = db.Column(db.Integer, nullable=False)
    class_attribute = db.Column(db.Integer, nullable=False)

    def __repr__(self):
        return f'<TA {self.id}>'


with app.app_context():
    db.create_all()

def ta_serializer(ta):
    return {
        'id': ta.id,
        'native_english_speaker': ta.native_english_speaker,
        'course_instructor': ta.course_instructor,
        'course': ta.course,
        'semester': ta.semester,
        'class_size': ta.class_size,
        'class_attribute': ta.class_attribute
    }

@app.route('/login', methods=['POST'])
def login():
    # get the user's credentials from the request
    username = request.json.get('username', None)
    password = request.json.get('password', None)

    # validate the user's credentials (e.g., check if they exist in the database)
    if not username or not password:
        return jsonify({'message': 'Missing username or password'}), 400
    elif username != 'musk' or password != '1111':
        return jsonify({'message': 'Invalid username or password'}), 401

    # create an access token for the user and return it as a response
    access_token = create_access_token(identity=username)
    return jsonify({'access_token': access_token}), 200


@app.route('/protected', methods=['GET'])
@jwt_required()
def protected():
    current_user = get_jwt_identity()
    return jsonify({'message': 'You are authorized to access this route', 'user': current_user}), 200


@app.route('/tas', methods=['GET', 'POST'])
@jwt_required()
def tas():
    if request.method == 'GET':
        tas = TA.query.all()
        return jsonify({'TAs': [ta_serializer(ta) for ta in tas]})

    elif request.method == 'POST':
        data = request.get_json()
        new_ta = TA(native_english_speaker=data['native_english_speaker'],
                    course_instructor=data['course_instructor'],
                    course=data['course'],
                    semester=data['semester'],
                    class_size=data['class_size'],
                    class_attribute=data['class_attribute'])
        db.session.add(new_ta)
        db.session.commit()

        # Serialize the TA object using the schema
        ta_schema = TASchema()
        result = ta_schema.dump(new_ta)

        response = {'message': 'New TA has been added successfully.', 'ta': result}
        return jsonify(response), 201


@app.route('/tas/<int:id>', methods=['GET', 'PUT', 'DELETE'])
@jwt_required()
def tas_id(id):
    ta = TA.query.filter_by(id=id).first()

    if not ta:
        return jsonify({'message': 'TA not found.'}), 404

    if request.method == 'GET':
        return jsonify({'TA': ta_serializer(ta)})

    elif request.method == 'PUT':
        data = request.get_json()
        ta.native_english_speaker = data['native_english_speaker']
        ta.course_instructor = data['course_instructor']
        ta.course = data['course']
        ta.semester = data['semester']
        ta.class_size = data['class_size']
        ta.class_attribute = data['class_attribute']
        db.session.commit()

        response = {'message': 'TA has been updated successfully.', 'ta': ta_serializer(ta)}
        return jsonify(response)

    elif request.method == 'DELETE':
        db.session.delete(ta)
        db.session.commit()

        return jsonify({'message': 'TA has been deleted successfully.'})


if __name__ == '__main__':
    app.run(debug=True)
